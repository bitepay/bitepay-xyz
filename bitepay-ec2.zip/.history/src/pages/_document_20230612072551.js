import { Html, Head, Main, NextScript } from 'next/document'

export default function Document() {
  return (
    <Html lang="en" datatheme="cmyk">
      <Head />
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  )
}
