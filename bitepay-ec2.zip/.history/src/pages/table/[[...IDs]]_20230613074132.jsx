import { useRouter } from 'next/router';
import { useContext } from 'react';
import Head from "next/head";
import Link from "next/link";

const Table = () => {
  
}


export default Table;